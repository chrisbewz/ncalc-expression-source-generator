﻿using VisitorTest.Abstractions;
using VisitorTest.Interfaces;
using VisitorTest.Visitor;

namespace VisitorTest.Implementations;

public class VisitableConcreteClass30 : AbstractVisitable<ConcreteClasses30Visitor>
{
    // your code goes here
    public VisitableConcreteClass30(IVisitor visitor) : base(visitor)
    {
        
    }
}