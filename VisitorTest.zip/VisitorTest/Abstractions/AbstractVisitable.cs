﻿using VisitorTest.Interfaces;

namespace VisitorTest.Abstractions;

public abstract class AbstractVisitable<TVisitor> : IVisitable<TVisitor>
where TVisitor : IVisitor
{
    private protected IVisitor _visitor;

    protected AbstractVisitable(IVisitor visitor)
    {
        _visitor ??= visitor;
    }
    
    public virtual void Accept(TVisitor visitor)
    {
        visitor.Visit(this);    
    }
}