﻿namespace VisitorTest.Interfaces;

public interface IVisitable
{
    
}