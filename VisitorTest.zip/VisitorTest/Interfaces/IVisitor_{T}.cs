﻿namespace VisitorTest.Interfaces;

public interface IVisitor
{
    void Visit(IVisitable visitable);
}