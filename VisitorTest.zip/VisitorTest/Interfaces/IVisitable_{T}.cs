﻿namespace VisitorTest.Interfaces;

public interface IVisitable<TVisitor> : IVisitable 
    where TVisitor : IVisitor
{
    void Accept(TVisitor visitor);
}