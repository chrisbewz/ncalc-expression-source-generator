﻿using VisitorTest.Interfaces;

namespace VisitorTest.Visitor;

public class ConcreteClasses30Visitor : IVisitor
{
    public void Visit(IVisitable visitable)
    {
        throw new NotImplementedException();
    }
}